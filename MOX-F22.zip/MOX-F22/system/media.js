import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { execFile } from 'child_process';
import { promisify } from 'util';

const execFileAsync = promisify(execFile);
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const TMP = path.join(__dirname, '..', 'media', 'tmp');

function ensureTmp() {
  if (!fs.existsSync(TMP)) fs.mkdirSync(TMP, { recursive: true });
}

function cleanOld() {
  try {
    const now = Date.now();
    for (const f of fs.readdirSync(TMP)) {
      const p = path.join(TMP, f);
      try {
        if (now - fs.statSync(p).mtimeMs > 30 * 60 * 1000) fs.unlinkSync(p);
      } catch {}
    }
  } catch {}
}

export async function hasYtDlp() {
  try {
    await execFileAsync('yt-dlp', ['--version'], { timeout: 10000 });
    return 'yt-dlp';
  } catch {
    try {
      await execFileAsync('youtube-dl', ['--version'], { timeout: 10000 });
      return 'youtube-dl';
    } catch {
      return false;
    }
  }
}

export async function downloadUrl(url, { audioOnly = false } = {}) {
  ensureTmp();
  cleanOld();
  const tool = await hasYtDlp();
  if (!tool) throw new Error('YTDLP_MISSING');

  const id = Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  const outTpl = path.join(TMP, id + '.%(ext)s');
  const args = ['--no-playlist', '--no-warnings', '-o', outTpl, '--max-filesize', '80M', '--socket-timeout', '30'];
  if (audioOnly) args.push('-x', '--audio-format', 'mp3', '--audio-quality', '0');
  else args.push('-f', 'bv*+ba/b', '--merge-output-format', 'mp4');
  args.push(url);

  try {
    await execFileAsync(tool, args, { timeout: 180000, maxBuffer: 12 * 1024 * 1024 });
  } catch (e1) {
    try {
      await execFileAsync(tool, ['--no-playlist', '--no-warnings', '-o', outTpl, url], { timeout: 180000, maxBuffer: 12 * 1024 * 1024 });
    } catch (e2) {
      throw new Error('DOWNLOAD_FAIL: ' + String(e2.stderr || e2.message || '').slice(0, 180));
    }
  }

  const files = fs.readdirSync(TMP).filter(f => f.startsWith(id));
  if (!files.length) throw new Error('DOWNLOAD_EMPTY');
  const file = path.join(TMP, files[0]);
  const ext = path.extname(file).toLowerCase();
  let type = 'document';
  if (['.mp4', '.mkv', '.webm', '.mov'].includes(ext)) type = 'video';
  else if (['.mp3', '.m4a', '.ogg', '.opus', '.wav'].includes(ext)) type = 'audio';
  else if (['.jpg', '.jpeg', '.png', '.webp'].includes(ext)) type = 'image';

  let title = path.basename(file);
  try {
    const { stdout } = await execFileAsync(tool, ['--get-title', '--no-playlist', url], { timeout: 20000 });
    if (stdout?.trim()) title = stdout.trim().slice(0, 120);
  } catch {}

  return { type, path: file, title, ext };
}

export async function searchAndDownload(query, { audioOnly = true } = {}) {
  const q = String(query || '').trim();
  if (!q) throw new Error('EMPTY_QUERY');
  return downloadUrl('ytsearch1:' + q, { audioOnly });
}

export function unlinkSafe(p) {
  try { if (p && fs.existsSync(p)) fs.unlinkSync(p); } catch {}
}
