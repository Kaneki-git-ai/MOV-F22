export default {
  botName: 'MOX F22',
  version: '1.0.3',
  prefix: ['.', '!', '/'],
  owners: [
    { name: 'KANEKI', phone: '01064875257', digits: '1064875257' },
    { name: 'VITAN', phone: '01205872535', digits: '1205872535' }
  ],
  ownerPhones: ['01064875257', '01205872535', '201064875257', '201205872535', '1064875257', '1205872535'],
  geminiKey: 'AQ.Ab8RN6JMApOhR9ot9VVEZJ2WracfHAmnFhGzubsAv6BuwJhWGw',
  grokKey: 'xai-bThcEn3pt4yXetH5DyI71VxNPegLMP1wWSpCFJ1yPzSTFHcZMPkILNE50UEKUU9OtVoqVIaNgN7ViyoT',
  welcome: 'اهلا بيك في MOX F22',
  goodbye: 'مع السلامة',
  stickerPack: 'KANEKI',
  stickerAuthor: 'MOX F22'
};
