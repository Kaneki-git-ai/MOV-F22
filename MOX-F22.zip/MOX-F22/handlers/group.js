import config from '../config.js';
import { group } from '../database/db.js';

export async function onGroupUpdate(sock, update) {
  try {
    const id = update.id;
    if (!id?.endsWith('@g.us')) return;
    const g = group(id);
    if (!g.welcome) return;

    if (update.action === 'add' && update.participants?.length) {
      for (const p of update.participants) {
        await sock.sendMessage(id, {
          text: `${config.welcome}\n@${p.split('@')[0]}`,
          mentions: [p]
        });
      }
    }
    if (update.action === 'remove' && update.participants?.length) {
      for (const p of update.participants) {
        await sock.sendMessage(id, { text: `${config.goodbye}` });
      }
    }
  } catch (e) {
    console.log('group:', e.message);
  }
}
