import { handleCommand } from '../commands/all.js';
import { isBanned, group, user } from '../database/db.js';
import { num, isOwner, unwrapMsg } from '../utils/helpers.js';

function pickSender(msg, sock) {
  const botJid = sock.user?.id || '';
  if (msg.key.fromMe) return botJid || msg.key.participant || msg.key.remoteJid;

  const candidates = [
    msg.key.participantPn,
    msg.key.participantAlt,
    msg.key.participant,
    msg.key.remoteJidAlt,
    msg.key.remoteJidPn,
    msg.key.remoteJid
  ].filter(Boolean);

  for (const c of candidates) {
    const n = num(c);
    if (n && n.length >= 9 && !String(c).includes('@lid')) return c;
  }
  for (const c of candidates) {
    if (num(c).length >= 9) return c;
  }
  return candidates[0] || botJid;
}

function extractText(message) {
  if (!message) return '';
  if (message.conversation) return message.conversation;
  if (message.extendedTextMessage?.text) return message.extendedTextMessage.text;
  if (message.imageMessage?.caption) return message.imageMessage.caption;
  if (message.videoMessage?.caption) return message.videoMessage.caption;
  if (message.documentMessage?.caption) return message.documentMessage.caption;
  return '';
}

export async function onMessage(sock, m) {
  try {
    const msg = m.messages?.[0];
    if (!msg?.message) return;

    const jid = msg.key.remoteJid;
    if (!jid || jid === 'status@broadcast') return;

    msg.message = unwrapMsg(msg.message) || msg.message;

    const sender = pickSender(msg, sock);
    if (!sender) return;
    if (isBanned(sender)) return;

    const text = (extractText(msg.message) || '').trim();
    if (msg.key.fromMe && text) {
      const isCmd = /^[.!\/]/.test(text) || /^(1[0-5]|[0-9])$/.test(text);
      if (!isCmd) return;
    }
    if (!text) return;

    if (jid.endsWith('@g.us')) {
      try {
        const g = group(jid);
        if (g.antilink && /(https?:\/\/|www\.|wa\.me|chat\.whatsapp)/i.test(text) && !msg.key.fromMe) {
          await sock.sendMessage(jid, { delete: msg.key });
          await sock.sendMessage(jid, { text: 'الروابط ممنوعة' });
          return;
        }
      } catch {}
    }

    user(sender, msg.pushName || (msg.key.fromMe ? 'Bot' : 'User'));
    await handleCommand(sock, msg, text, sender);
  } catch (e) {
    console.error('msg:', e.message);
  }
}
