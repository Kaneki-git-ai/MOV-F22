import makeWASocket, {
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  makeCacheableSignalKeyStore
} from '@whiskeysockets/baileys';
import pino from 'pino';
import qrcode from 'qrcode-terminal';
import path from 'path';
import { fileURLToPath } from 'url';
import config from './config.js';
import { onMessage } from './handlers/message.js';
import { onGroupUpdate } from './handlers/group.js';
import { isOwner, num, ownerLabel } from './utils/helpers.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const sessionDir = path.join(__dirname, 'session');

const P = '\x1b[38;5;129m';
const M = '\x1b[38;5;165m';
const R = '\x1b[38;5;160m';
const D = '\x1b[38;5;88m';
const W = '\x1b[37m';
const G = '\x1b[32m';
const Y = '\x1b[33m';
const X = '\x1b[0m';
const B = '\x1b[1m';

function forceOwner(any) {
  const d = String(any || '').split('@')[0].split(':')[0].replace(/\D/g, '');
  if (!d) return false;
  const l9 = d.slice(-9);
  if (l9 === '1064875257') return 'KANEKI';
  if (l9 === '1205872535') return 'VITAN';
  return false;
}

function printBanner() {
  console.clear();
  console.log('');
  console.log(B + P + '  ███╗   ███╗ ██████╗ ██╗  ██╗    ███████╗██████╗ ██████╗ ' + X);
  console.log(B + M + '  ████╗ ████║██╔═══██╗╚██╗██╔╝    ██╔════╝╚════██╗╚════██╗' + X);
  console.log(B + R + '  ██╔████╔██║██║   ██║ ╚███╔╝     █████╗   █████╔╝ █████╔╝' + X);
  console.log(B + R + '  ██║╚██╔╝██║██║   ██║ ██╔██╗     ██╔══╝  ██╔═══╝ ██╔═══╝ ' + X);
  console.log(B + D + '  ██║ ╚═╝ ██║╚██████╔╝██╔╝ ██╗    ██║     ███████╗███████╗' + X);
  console.log(B + D + '  ╚═╝     ╚═╝ ╚═════╝ ╚═╝  ╚═╝    ╚═╝     ╚══════╝╚══════╝' + X);
  console.log('');
  console.log(W + '  ' + config.botName + '  v' + config.version + '  [react]' + X);
  console.log(W + '  Owners : KANEKI + VITAN' + X);
  console.log(W + '  Prefix : .  !  /' + X);
  console.log('');
}

async function getVersion() {
  try {
    console.log(Y + '  [...] جلب إصدار واتساب (10 ثواني كحد أقصى)' + X);
    const result = await Promise.race([
      fetchLatestBaileysVersion(),
      new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), 10000))
    ]);
    console.log(G + '  [OK] version ' + (result?.version || '').toString() + X);
    return result?.version;
  } catch (e) {
    console.log(Y + '  [!] تخطي جلب الإصدار — استخدام الافتراضي (' + e.message + ')' + X);
    return undefined;
  }
}

async function start() {
  printBanner();
  console.log(Y + '  [...] تحميل الجلسة' + X);
  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
  console.log(G + '  [OK] الجلسة جاهزة' + X);

  const version = await getVersion();
  const logger = pino({ level: 'silent' });

  console.log(Y + '  [...] فتح اتصال واتساب' + X);

  const sockOptions = {
    logger,
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, logger)
    },
    printQRInTerminal: false,
    generateHighQualityLinkPreview: false,
    syncFullHistory: false,
    markOnlineOnConnect: false,
    connectTimeoutMs: 60000,
    defaultQueryTimeoutMs: 60000,
    keepAliveIntervalMs: 10000
  };
  if (version) sockOptions.version = version;

  const sock = makeWASocket(sockOptions);

  sock.ev.on('creds.update', saveCreds);

  sock.ev.on('connection.update', (u) => {
    const { connection, lastDisconnect, qr } = u;
    if (qr) {
      printBanner();
      console.log(P + '  امسح الباركود الآن من واتساب' + X);
      console.log(W + '  الإعدادات → الأجهزة المرتبطة → ربط جهاز' + X);
      console.log('');
      qrcode.generate(qr, { small: true });
      console.log('');
      console.log(Y + '  استنى بعد المسح... (قد يأخذ دقيقة)' + X);
    }
    if (connection === 'connecting') {
      console.log(Y + '  [...] جاري الاتصال...' + X);
    }
    if (connection === 'open') {
      const jid = sock.user?.id || '';
      const rawPhone = String(jid).split('@')[0].split(':')[0].replace(/\D/g, '');
      const phone = num(jid) || rawPhone;
      const forced = forceOwner(jid) || forceOwner(phone) || forceOwner(rawPhone);
      const own = !!forced || isOwner(jid) || isOwner(phone);
      const label = forced || ownerLabel(jid) || ownerLabel(phone) || 'OWNER';
      console.log('');
      console.log(G + '  [ MOX F22 ONLINE ]' + X);
      console.log(W + '  Phone : ' + phone + X);
      console.log(W + '  Owner : ' + (own ? 'YES (' + label + ')' : 'NO') + X);
      console.log(W + '  JID   : ' + jid + X);
      console.log(W + '  last9 : ' + String(phone).slice(-9) + X);
      console.log('');
    }
    if (connection === 'close') {
      const code = lastDisconnect?.error?.output?.statusCode;
      const msg = lastDisconnect?.error?.message || '';
      console.log(R + '  [CLOSE] code=' + (code || '?') + ' ' + msg + X);
      if (code !== DisconnectReason.loggedOut) {
        console.log(Y + '  إعادة المحاولة بعد 3 ثواني...' + X);
        setTimeout(start, 3000);
      } else {
        console.log(W + '  تم تسجيل الخروج — امسح session واربط من جديد:' + X);
        console.log(W + '  rm -rf session && node index.js' + X);
      }
    }
  });

  sock.ev.on('messages.upsert', (m) => onMessage(sock, m));
  sock.ev.on('group-participants.update', (u) => onGroupUpdate(sock, u));
}

start().catch((e) => {
  console.error(R + ' start error: ' + e.message + X);
  console.log(Y + '  إعادة بعد 5 ثواني...' + X);
  setTimeout(start, 5000);
});
