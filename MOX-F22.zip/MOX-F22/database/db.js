import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { num } from '../utils/helpers.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = path.join(__dirname, '..', 'data.json');

function load() {
  try {
    if (fs.existsSync(DB_PATH)) return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
  } catch {}
  return { users: {}, groups: {}, bans: {}, pending: {}, menu: {} };
}

function save(data) {
  try {
    fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
  } catch (e) {
    console.log('db save:', e.message);
  }
}

let db = load();

export function user(jid, name) {
  const id = num(jid) || String(jid);
  if (!db.users[id]) {
    db.users[id] = { name: name || 'User', points: 0, xp: 0, level: 1, bank: 0, daily: 0, warn: 0 };
    save(db);
  } else if (name) {
    db.users[id].name = name;
    save(db);
  }
  return db.users[id];
}

export function addPoints(jid, amount) {
  const u = user(jid);
  u.points = (u.points || 0) + amount;
  u.xp = (u.xp || 0) + Math.abs(amount);
  u.level = 1 + Math.floor((u.xp || 0) / 100);
  save(db);
  return u;
}

export function group(jid) {
  if (!db.groups[jid]) {
    db.groups[jid] = { antilink: false, welcome: true, mute: false };
    save(db);
  }
  return db.groups[jid];
}

export function setGroup(jid, key, val) {
  const g = group(jid);
  g[key] = val;
  save(db);
  return g;
}

export function ban(jid, on = true) {
  const id = num(jid) || String(jid);
  if (on) db.bans[id] = true;
  else delete db.bans[id];
  save(db);
}

export function isBanned(jid) {
  const id = num(jid) || String(jid);
  return !!db.bans[id];
}

export function pendingAdd(phone, name) {
  db.pending[phone] = { name, at: Date.now() };
  save(db);
}

export function pendingRemove(phone) {
  delete db.pending[phone];
  save(db);
}

export function pendingList() {
  return Object.entries(db.pending || {}).map(([phone, v]) => ({ phone, ...v }));
}

export function getMenuState(jid) {
  return db.menu[num(jid) || jid] || null;
}

export function setMenuState(jid, state) {
  const id = num(jid) || jid;
  if (state == null) delete db.menu[id];
  else db.menu[id] = state;
  save(db);
}
